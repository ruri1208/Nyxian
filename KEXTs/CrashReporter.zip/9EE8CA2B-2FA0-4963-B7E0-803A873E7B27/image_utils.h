//
// image_utils.h
// CrashReporter
//
// Created by mach-port-t on 02.09.26.
//

#ifndef IMAGE_UTILS_H
#define IMAGE_UTILS_H

@import Foundation;
@import MachO;
@import Darwin;

NSArray *used_images_for_task(task_t task, NSDictionary **sharedCache);

#endif /* IMAGE_UTILS_H */
