//
// vm_summary.m
// CrashReporter
//
// Created by Anonym on 01.09.26.
//

@import Darwin;
@import Foundation;

// Yes this part is skidded, you cant expect that im a mach vm lexicon xD

// VM_MEMORY_* tag → human label. Covers the common tags; extend as you see
// "Untagged" buckets you'd rather name. Full list is in <mach/vm_statistics.h>.
static NSString *label_for_tag(unsigned tag)
{
    switch (tag) {
        case VM_MEMORY_MALLOC:                 return @"Malloc";
        case VM_MEMORY_MALLOC_SMALL:           return @"Malloc";
        case VM_MEMORY_MALLOC_LARGE:           return @"Malloc";
        case VM_MEMORY_MALLOC_HUGE:            return @"Malloc";
        case VM_MEMORY_MALLOC_TINY:            return @"Malloc";
        case VM_MEMORY_MALLOC_NANO:            return @"Malloc";
        case VM_MEMORY_MALLOC_MEDIUM:          return @"Malloc";
        case VM_MEMORY_MALLOC_LARGE_REUSABLE:  return @"Malloc";
        case VM_MEMORY_MALLOC_LARGE_REUSED:    return @"Malloc";
        case VM_MEMORY_SANITIZER:              return @"Sanitizer";
        case VM_MEMORY_STACK:                  return @"Stack";
        case VM_MEMORY_GUARD:                  return @"Stack Guard";
        case VM_MEMORY_DYLIB:                  return @"mapped file";
        case VM_MEMORY_DYLD:                   return @"Dyld Private Memory";
        case VM_MEMORY_DYLD_MALLOC:            return @"Dyld Private Memory";
        case VM_MEMORY_SHARED_PMAP:            return @"shared memory";
        case VM_MEMORY_UNSHARED_PMAP:          return @"shared memory";
        case VM_MEMORY_MACH_MSG:               return @"Mach Message";
        case VM_MEMORY_IOKIT:                  return @"IOKit";
        case VM_MEMORY_OS_ALLOC_ONCE:          return @"OS Alloc Once";
        case VM_MEMORY_FOUNDATION:             return @"Foundation";
        case VM_MEMORY_COREGRAPHICS:           return @"CoreGraphics";
        case VM_MEMORY_CORESERVICES:           return @"CoreServices";
        case VM_MEMORY_COREDATA:               return @"CoreData";
        case VM_MEMORY_COREDATA_OBJECTIDS:     return @"CoreData Object IDs";
        case VM_MEMORY_COREUI:                 return @"CoreUI Image Data";
        case VM_MEMORY_LAYERKIT:               return @"CoreAnimation";
        case VM_MEMORY_CGIMAGE:                return @"CG Image";
        case VM_MEMORY_IMAGEIO:                return @"ImageIO";
        case VM_MEMORY_JAVASCRIPT_CORE:        return @"JS VM";
        case VM_MEMORY_JAVASCRIPT_JIT_EXECUTABLE_ALLOCATOR: return @"JS JIT";
        case VM_MEMORY_APPLICATION_SPECIFIC_1: return @"App-Specific Tag 16";
        case VM_MEMORY_ACCELERATE:             return @"Accelerate Framework";
        case VM_MEMORY_SQLITE:                 return @"SQLite Page Cache";
        case 0:                                return @"Untagged";
        default:                               return @"Untagged";
    }
}

// human-readable size the way vmmap prints it: K / M / G
static NSString *fmt_size(uint64_t bytes)
{
    if (bytes >= (1024ull * 1024 * 1024))
        return [NSString stringWithFormat:@"%.1fG", bytes / (1024.0 * 1024 * 1024)];
    if (bytes >= (1024ull * 1024))
        return [NSString stringWithFormat:@"%.1fM", bytes / (1024.0 * 1024)];
    if (bytes >= 1024ull)
        return [NSString stringWithFormat:@"%lluK", bytes / 1024];
    return [NSString stringWithFormat:@"%llu", bytes];
}

NSString *vm_summary_for_task(task_t task)
{
    // label -> [totalSize, count]
    NSMutableDictionary<NSString*, NSMutableArray*> *buckets = [NSMutableDictionary dictionary];

    vm_address_t addr = 0;
    uint64_t grandTotal = 0;
    uint64_t grandCount = 0;

    uint64_t residentBytes = 0;
    uint64_t dirtyBytes    = 0;
    uint64_t swappedBytes  = 0;

    const int MAX_REGIONS = 100000;   // hard cap so a bad map can't spin us
    int walked = 0;

    for (walked = 0; walked < MAX_REGIONS; walked++) {
        vm_size_t size = 0;
        vm_region_submap_info_data_64_t info;
        mach_msg_type_number_t cnt = VM_REGION_SUBMAP_INFO_COUNT_64;
        natural_t depth = 0;

        kern_return_t kr = vm_region_recurse_64(task, &addr, &size, &depth, (vm_region_recurse_info_t)&info, &cnt);
        if (kr != KERN_SUCCESS) break;   // walked off the end of the map

        // descend into submaps so we account leaf regions, not the container
        if (info.is_submap) { depth++; continue; }

        NSString *label = label_for_tag(info.user_tag);

        NSMutableArray *b = buckets[label];
        if (!b) { b = [NSMutableArray arrayWithObjects:@(0ull), @(0ull), nil]; buckets[label] = b; }
        b[0] = @([b[0] unsignedLongLongValue] + (uint64_t)size);
        b[1] = @([b[1] unsignedLongLongValue] + 1);

        grandTotal += (uint64_t)size;
        grandCount += 1;

        residentBytes += (uint64_t)info.pages_resident      * PAGE_SIZE;
        dirtyBytes    += (uint64_t)info.pages_dirtied        * PAGE_SIZE;
        swappedBytes  += (uint64_t)info.pages_swapped_out    * PAGE_SIZE;

        addr += size;   // advance past this region
    }

    // ---- format ----
    NSMutableString *out = [NSMutableString string];

    // header
    [out appendFormat:@"Physical footprint: %@\n", fmt_size(residentBytes)];
    [out appendFormat:@"Writable regions: Total=%@ dirty=%@ swapped_out=%@\n\n",
                      fmt_size(grandTotal), fmt_size(dirtyBytes), fmt_size(swappedBytes)];

    [out appendString:@"                                VIRTUAL   REGION \n"];
    [out appendString:@"REGION TYPE                        SIZE    COUNT (non-coalesced) \n"];
    [out appendString:@"===========                     =======  ======= \n"];

    // sorted by label for stable output

    // pad helper: left-justify a string to `width` with spaces
    NSString *(^padRight)(NSString *, NSUInteger) = ^NSString *(NSString *s, NSUInteger width) {
        if (s.length >= width) return s;
        return [s stringByPaddingToLength:width withString:@" " startingAtIndex:0];
    };
    NSString *(^padLeft)(NSString *, NSUInteger) = ^NSString *(NSString *s, NSUInteger width) {
        if (s.length >= width) return s;
        NSUInteger pad = width - s.length;
        return [[@"" stringByPaddingToLength:pad withString:@" " startingAtIndex:0]
                stringByAppendingString:s];
    };

    NSArray *labels = [buckets.allKeys sortedArrayUsingSelector:@selector(compare:)];
    for (NSString *label in labels) {
        NSArray *b = buckets[label];
        uint64_t sz  = [b[0] unsignedLongLongValue];
        uint64_t cnt = [b[1] unsignedLongLongValue];
        [out appendFormat:@"%@%@ %@ \n",
                          padRight(label, 32),
                          padLeft(fmt_size(sz), 7),
                          padLeft([NSString stringWithFormat:@"%llu", cnt], 7)];
    }

    [out appendString:@"===========                     =======  ======= \n"];
    [out appendFormat:@"%@%@ %@\n",
                      padRight(@"TOTAL", 32),
                      padLeft(fmt_size(grandTotal), 7),
                      padLeft([NSString stringWithFormat:@"%llu", grandCount], 7)];


    return out;
}

