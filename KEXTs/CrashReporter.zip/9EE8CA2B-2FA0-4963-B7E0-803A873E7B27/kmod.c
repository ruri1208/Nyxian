//
// Main.c
// CrashReporter
//
// Created by Anonym on 01.09.26.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <LindChain/ProcEnvironment/Utils/klog.h>
#include <LindChain/ProcEnvironment/Surface/kxld/image.h>
#include <LindChain/ProcEnvironment/Surface/fs/mount.h>
#include <LindChain/ProcEnvironment/Surface/sys/core.h>
#include <ksurface_abi.h>
#include "handoffep+crashreporter.h"

extern kern_return_t ksurface_relhomemount_mount(FSMountAttr attr, const char *mount_dir, const char *target_dir);

kern_return_t kinit(void)
{
	klog_log("org.emexlabs.CrashReporter", "initialize crashreporter file system");
	
	typedef struct {
		FSMountAttr permissionFlags;
		const char *mount;
		const char *target;
	} FSMountInitRegistry;
	
	/* something like fstab x3 */
	FSMountInitRegistry fstab[] = {
		/* crashreporterfs */
		{
			kFSMountAttrRead | kFSMountAttrWrite,
			"/Documents/mntfs/rootfs/var/crashreporter",
		},
	};
	
	for(int i = 0; i < sizeof(fstab) / sizeof(FSMountInitRegistry); i++)
	{
		kern_return_t kr = ksurface_relhomemount_mount(fstab[i].permissionFlags, fstab[i].mount, fstab[i].target);
		if(kr != KERN_SUCCESS)
		{
			klog_log("org.emexlabs.CrashReporter", "failed to create %s userspace mount", fstab[i].mount);
			return KERN_FAILURE;
		}
	}
	
	klog_log("org.emexlabs.CrashReporter", "bootstrapping exception server");
	bootstrap_crashreporter();
	
	klog_log("org.emexlabs.CrashReporter", "setting syscall mod");
	/*
	 * in-case other kext's need to grab the task port at
	 * some point too and use the same kind of trampoline
	 * we shall not replace it, but since init is synchronious
	 * we can just staircase it.
	 */
	syscall_server_handler_handoffep_handler = syscall_server_get_handler(ksurface->sys_server, SYS_handoffep);	/* so it can call the most previous registered handler */
	syscall_server_register(ksurface->sys_server, SYS_handoffep, GET_SYSCALL_HANDLER(handoffep_mod));
	
	return KERN_SUCCESS;
}

EXPORT_KSURFACE_MODULE({
	.magic = KSURFACE_KMOD_MAGIC,
	.abi_version = KSURFACE_KMOD_ABI_VERSION,
	.identifier = "org.emexlabs.CrashReporter",
	.version = KMOD_VERSION(1, 0, 1),
	.flags = KMOD_FLAG_PERSISTENT | KMOD_FLAG_OVERRIDE_CORE,
	.dependency_count = 3,
	.init = kinit,
	.deinit = NULL,
	.start = NULL,
	.stop = NULL,
	.dependencies = {
		{
			.identifier = "com.apple.iphoneos",
			.min_version = KMOD_VERSION(18, 4, 0),
			.max_version = KMOD_VERSION(99, 99, 99), /* depends on apple's mood swings */
		},
		{
			.identifier = "ksurface",
			.min_version = KMOD_VERSION(0, 11, 4),
			.max_version = KMOD_VERSION(0, 11, 4),
		},
		{
			.identifier = "org.emexlabs.RelHomeMount",
			.min_version = KMOD_VERSION(1, 0, 0),
			.max_version = KMOD_VERSION(1, 0, 0),
		}
	},
})
