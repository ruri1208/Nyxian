//
// handoffep+crashreporter.h
// CrashReporter
//
// Created by Anonym on 01.09.26.
//

#ifndef HANDOFFEP_CRASHREPORTER_H
#define HANDOFFEP_CRASHREPORTER_H

#if __OBJC__
@import Foundation;
#endif /* __OBJC__ */
#include <LindChain/ProcEnvironment/Surface/surface.h>

extern syscall_handler_t syscall_server_handler_handoffep_handler;

DEFINE_SYSCALL_HANDLER(handoffep_mod);

void bootstrap_crashreporter(void);

#endif /* HANDOFFEP_CRASHREPORTER_H */
