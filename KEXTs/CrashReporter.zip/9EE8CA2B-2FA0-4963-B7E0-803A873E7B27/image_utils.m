//
// image_utils.m
// CrashReporter
//
// Created by mach-port-t on 02.09.26.
//

#import "image_utils.h"

struct dyld_cache_header_prefix {
	char magic[16];
	uint32_t mappingOffset;
	uint32_t mappingCount;
	/* following more fields nobody needs */
};

struct dyld_cache_mapping_info {
	uint64_t address;
	uint64_t size;
	uint64_t fileOffset;
	uint32_t maxProt;
	uint32_t initProt;
};

static inline uint64_t shared_cache_mapped_size(task_t task, uint64_t base)
{
	struct dyld_cache_header_prefix hdr;
	vm_size_t got = 0;
	if(vm_read_overwrite(task, (vm_address_t)base, sizeof hdr, (vm_address_t)&hdr, &got) != KERN_SUCCESS || got != sizeof hdr)
	{
		return 0;
	}
	
	if(strncmp(hdr.magic, "dyld_", 5) != 0)
	{
		return 0;
	}
	if(hdr.mappingCount == 0 || hdr.mappingCount > 8)
	{
		return 0;
	}
	uint64_t total = 0;
	for(uint32_t i = 0; i < hdr.mappingCount; i++)
	{
		struct dyld_cache_mapping_info m;
		uint64_t off = base + hdr.mappingOffset + i * sizeof(m);
		if(vm_read_overwrite(task, (vm_address_t)off, sizeof m, (vm_address_t)&m, &got) != KERN_SUCCESS || got != sizeof m)
		{
			return total;
		}
		total += m.size;
	}
	return total;
}

static inline NSDictionary *shared_cache_for_task(task_t task, const struct dyld_all_image_infos *aii)
{
	uint64_t base = (uint64_t)aii->sharedCacheBaseAddress;
	
	char uuidstr[37];
	uuid_unparse_lower(aii->sharedCacheUUID, uuidstr);
	
	uint64_t size = shared_cache_mapped_size(task, base);
	return @{
		@"base": @(base),
		@"size": @(size),
		@"uuid": @(uuidstr),
	};
}

NSArray *used_images_for_task(task_t task, NSDictionary **sharedCache)
{
	NSMutableArray *images = [NSMutableArray array];
	
	task_dyld_info_data_t dinfo;
	mach_msg_type_number_t dcnt = TASK_DYLD_INFO_COUNT;
	if(task_info(task, TASK_DYLD_INFO, (task_info_t)&dinfo, &dcnt) != KERN_SUCCESS)
	{
		return images;
	}
	
	struct dyld_all_image_infos aii;
	vm_size_t got = 0;
	if(vm_read_overwrite(task, (vm_address_t)dinfo.all_image_info_addr, sizeof aii, (vm_address_t)&aii, &got) != KERN_SUCCESS || got != sizeof aii)
	{
		return images;
	}
	
	uint32_t count = aii.infoArrayCount;
	if(count == 0 || count > 4096)
	{
		return images;
	}
	size_t arrsz = count * sizeof(struct dyld_image_info);
	struct dyld_image_info *arr = malloc(arrsz);
	if(vm_read_overwrite(task, (vm_address_t)aii.infoArray, arrsz, (vm_address_t)arr, &got) != KERN_SUCCESS || got != arrsz)
	{
		free(arr);
		return images;
	}
	
	for(uint32_t i = 0; i < count; i++)
	{
		uint64_t load_addr = (uint64_t)arr[i].imageLoadAddress;
		
		struct mach_header_64 mh;
		if(vm_read_overwrite(task, (vm_address_t)load_addr, sizeof mh, (vm_address_t)&mh, &got) != KERN_SUCCESS || got != sizeof mh || mh.magic != MH_MAGIC_64)
		{
			continue;
		}
		
		size_t cmdsz = mh.sizeofcmds;
		uint8_t *cmds = malloc(cmdsz);
		if(vm_read_overwrite(task, (vm_address_t)(load_addr + sizeof mh), cmdsz, (vm_address_t)cmds, &got) != KERN_SUCCESS || got != cmdsz)
		{
			free(cmds);
			continue;
		}
		
		uint64_t textsize = 0;
		uuid_t uuid; memset(uuid, 0, sizeof uuid);
		const uint8_t *p = cmds;
		for(uint32_t c = 0; c < mh.ncmds; c++)
		{
			const struct load_command *lc = (const struct load_command *)p;
			if(lc->cmd == LC_UUID)
			{
				memcpy(uuid, ((const struct uuid_command *)lc)->uuid, sizeof uuid);
			}
			else if(lc->cmd == LC_SEGMENT_64)
			{
				const struct segment_command_64 *seg = (const struct segment_command_64 *)lc;
				if(strcmp(seg->segname, "__TEXT") == 0)
				{
					textsize = seg->vmsize;
				}
			}
			p += lc->cmdsize;
		}
		free(cmds);
		
		char path[1024] = {0};
		if(arr[i].imageFilePath)
		{
			vm_read_overwrite(task, (vm_address_t)arr[i].imageFilePath, sizeof path - 1, (vm_address_t)path, &got);
		}
		
		char uuidstr[37];
		uuid_unparse_lower(uuid, uuidstr);
		NSString *ns = [NSString stringWithUTF8String:path];
		
		const char *archName = "arm64";
		if(mh.cputype == CPU_TYPE_ARM64 && (mh.cpusubtype & ~CPU_SUBTYPE_MASK) == CPU_SUBTYPE_ARM64E)
		{
			archName = "arm64e";
		}
		
		[images addObject:@{
			@"base": @(load_addr),
			@"size": @(textsize),
			@"uuid": @(uuidstr),
			@"path": ns ?: @"",
			@"name": ns.lastPathComponent ?: @"",
			@"arch": @(archName),
		}];
	}
	free(arr);
	
	if(sharedCache)
	{
		*sharedCache = shared_cache_for_task(task, &aii);
	}
	
	return images;
}

