//
// exc_utils.h
// CrashReporter
//
// Created by mach-port-t on 02.09.26.
//

#ifndef EXC_UTILS_H
#define EXC_UTILS_H

@import Darwin;

const char *exc_type_name(exception_type_t t);
static inline const char *signal_name(int sig);
const char *exc_signal_name(exception_type_t exc, int64_t code0);

#endif /* EXC_UTILS_H */
