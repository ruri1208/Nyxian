//
// handoffep+crashreporter.m
// CrashReporter
//
// Created by Anonym on 01.09.26.
//

#import <LindChain/ProcEnvironment/Utils/klog.h>
#import <LindChain/ProcEnvironment/Surface/proc/lookup.h>
#import <LindChain/ProcEnvironment/Surface/kxld/image.h>
#import "handoffep+crashreporter.h"
#import "ipsgen.h"

typedef struct {
	union {
		__Request__exception_raise_t v;
		uint8_t pad[1024];
	};
} __Request__exception_raise_large_t;

/* structure to get the exception */
static NSUUID *bootSessionUUID = nil;
static mach_port_t exception_port = MACH_PORT_NULL;

void *exception_server(void *ctx)
{
	__Request__exception_raise_large_t request;
	kern_return_t kr;
	
	for(;;)
	{
		klog_log("org.emexlabs.CrashReporter", "exception server armed");
		
		/* receiving exceptions caused by guest */
		request.v.Head.msgh_local_port = exception_port;
		request.v.Head.msgh_size = (mach_msg_size_t)sizeof(request);
		mach_msg_return_t mr = mach_msg(&(request.v.Head), MACH_RCV_MSG, 0, sizeof(request), exception_port, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);
		if(mr != MACH_MSG_SUCCESS)
		{
			klog_log("org.emexlabs.CrashReporter", "failed to receive exception from guest: %s", mach_error_string(mr));
			continue;
		}
		
		/* validating message header */
		if((request.v.Head.msgh_bits & MACH_MSGH_BITS_COMPLEX) == 0 || (request.v.Head.msgh_bits & MACH_MSGH_BITS_PORTS_MASK) != MACH_MSGH_BITS(MACH_MSG_TYPE_PORT_SEND_ONCE, MACH_MSG_TYPE_PORT_SEND))
		{
			klog_log("org.emexlabs.CrashReporter", "malformed mach message header");
			goto out_failure;
		}
		
		/* validate message descriptors */
		if(request.v.msgh_body.msgh_descriptor_count != 2 || request.v.thread.type != MACH_MSG_PORT_DESCRIPTOR || request.v.task.type != MACH_MSG_PORT_DESCRIPTOR)
		{
			klog_log("org.emexlabs.CrashReporter", "malformed mach message body");
			goto out_failure;
		}
		
		/* task + thread port validation */
		ipc_info_object_type_t type[2];
		mach_vm_address_t address;
		kern_return_t kr = mach_port_kobject(mach_task_self(), request.v.task.name, &type[0], &address);
		if(kr != KERN_SUCCESS)
		{
			klog_log("org.emexlabs.CrashReporter", "failed getting the kobject type: %s", mach_error_string(kr));
			goto out_failure;
		}
		
		kr = mach_port_kobject(mach_task_self(), request.v.thread.name, &type[1], &address);
		if(kr != KERN_SUCCESS)
		{
			klog_log("org.emexlabs.CrashReporter", "failed getting the kobject type: %s", mach_error_string(kr));
			goto out_failure;
		}
		
		/* checking for ipc object type */
		if(type[0] != IPC_OTYPE_TASK_CONTROL || type[1] != IPC_OTYPE_THREAD_CONTROL)
		{
			klog_log("org.emexlabs.CrashReporter", "port validation failed");
			goto out_failure;
		}
		
		/* exception handling */
		exception_type_t exc_type = request.v.exception;
		mach_msg_type_number_t code_count = request.v.codeCnt;
		
		klog_log("org.emexlabs.CrashReporter", "exception has been received");
		
		if(request.v.task.name != mach_task_self())
		{
			task_suspend(request.v.task.name);
		}
		
		generateIPS(request.v.task.name, request.v.thread.name, request.v.exception, request.v.codeCnt, request.v.code, bootSessionUUID);
		
		/* clearing exception port */
		task_set_exception_ports(request.v.task.name, EXC_MASK_ALL | EXC_MASK_CRASH, MACH_PORT_NULL, EXCEPTION_DEFAULT, THREAD_STATE_NONE);
		
		if(request.v.task.name != mach_task_self())
		{
			task_resume(request.v.task.name);
		}
		
	out_destroy_request:
		{
			/* after replying the kernel will happily continue executing the task */
			__Reply__exception_raise_t reply;
			memset(&reply, 0, sizeof(reply));
			reply.Head.msgh_bits = MACH_MSGH_BITS(MACH_MSGH_BITS_REMOTE(request.v.Head.msgh_bits), 0);
			reply.Head.msgh_id = request.v.Head.msgh_id + 100;
			reply.Head.msgh_local_port = MACH_PORT_NULL;
			reply.Head.msgh_remote_port = request.v.Head.msgh_remote_port;
			reply.Head.msgh_size = sizeof(reply);
			reply.NDR = NDR_record;
			reply.RetCode = KERN_FAILURE;	/* crashreporter just writes as we get the exception, there is no exception handling */
			mr = mach_msg(&reply.Head, MACH_SEND_MSG, reply.Head.msgh_size, 0, MACH_PORT_NULL, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);
			if(mr == KERN_SUCCESS)
			{
				request.v.Head.msgh_remote_port = MACH_PORT_NULL;
			}
			else
			{
				klog_log("org.emexlabs.CrashReporter", "failed to reply back to kernel: %s", mach_error_string(mr));
			}
			
			mach_msg_destroy(&(request.v.Head));
			continue;
		}
	out_failure:
		kr = KERN_FAILURE;
		goto out_destroy_request;
	out_failure_resume:
		if(request.v.task.name != mach_task_self())
		{
			task_resume(request.v.task.name);
			goto out_failure;
		}
	}
	
	return NULL;
}

/* interception of ksurface to get the task port exactly when it gets aquired */
syscall_handler_t syscall_server_handler_handoffep_handler = NULL;
DEFINE_SYSCALL_HANDLER(handoffep_mod)
{
	int64_t ret = SYSCALL_HANDLER_REDIRECT_TO_HANDLER(handoffep_handler);
	klog_log("org.emexlabs.CrashReporter", "(real return = %d)", ret);
	if(ret == 0)
	{
		/* getting the bricks needed for the crashreporter */
		task_t task = MACH_PORT_NULL;
		kern_return_t kr = proc_task_for_proc(sys_proc_, TASK_KERNEL_PORT, &task);
		if(kr == KERN_SUCCESS)
		{
			klog_log("org.emexlabs.CrashReporter", "(got task = %u)", task);
			
			if(exception_port == MACH_PORT_NULL)
			{
				klog_log("org.emexlabs.CrashReporter", "no exception server", mach_error_string(kr));
				mach_port_deallocate(mach_task_self(), task);
			}
			else
			{
				klog_log("org.emexlabs.CrashReporter", "attaching exception server");
				
				kr = task_set_exception_ports(task, EXC_MASK_ALL | EXC_MASK_CRASH, exception_port, EXCEPTION_DEFAULT, ARM_THREAD_STATE64);
				mach_port_deallocate(mach_task_self(), task);
				if(kr != KERN_SUCCESS)
				{
					klog_log("org.emexlabs.CrashReporter", "failed to attach to exception server: %s", mach_error_string(kr));
				}
			}
		}
	}
	return ret;
}

void bootstrap_crashreporter(void)
{
	klog_log("org.emexlabs.CrashReporter", "bootstrapping crash exception server");
	
	bootSessionUUID = [NSUUID UUID];
	
	mach_port_options_t opt = {
		.flags =  MPO_PORT | MPO_INSERT_SEND_RIGHT
	};
	
	kern_return_t kr = mach_port_construct(mach_task_self(), &opt, 0, &exception_port);
	if(kr != KERN_SUCCESS)
	{
		klog_log("org.emexlabs.CrashReporter", "failed to construct mach port: %s", mach_error_string(kr));
		return;
	}
	
	pthread_t thread;
	if(pthread_create(&thread, NULL, exception_server, NULL) != 0)
	{
		return;
	}
	pthread_detach(thread);
	
	/* checking if debugger is attached, like LLDB or GDB */
	if(getpid() == 1)	/* when launchd is the parent it is unlikely */
	{
		kr = task_set_exception_ports(mach_task_self(), EXC_MASK_ALL | EXC_MASK_CRASH, exception_port, EXCEPTION_DEFAULT, ARM_THREAD_STATE64);
		if(kr != KERN_SUCCESS)
		{
			klog_log("org.emexlabs.CrashReporter", "failed to attach exception server to self: %s", mach_error_string(kr));
		}
	}
}
