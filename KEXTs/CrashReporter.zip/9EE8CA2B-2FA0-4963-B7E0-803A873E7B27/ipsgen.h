//
// ipsgen.h
// CrashReporter
//
// Created by mach-port-t on 02.09.26.
//

#ifndef IPSGEN_H
#define IPSGEN_H

@import Foundation;
@import Darwin;

void generateIPS(task_t task, thread_t thread, exception_type_t exc_type, mach_msg_type_number_t code_count, integer_t code[2], NSUUID *bootSessionUUID);

#endif /* IPSGEN_H */
