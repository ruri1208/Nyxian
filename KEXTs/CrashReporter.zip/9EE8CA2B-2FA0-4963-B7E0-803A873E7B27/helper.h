//
// helper.h
// CrashReporter
//
// Created by mach-port-t on 02.09.26.
//

#ifndef HELPER_H
#define HELPER_H

@import Foundation;
@import Darwin;
@import CommonCrypto;

@interface NSString (PECrashreporter)

- (BOOL)isEmpty;

@end

NSString *make_timestamp(NSDate *date);
NSString *model_code(void);
NSString *crash_reporter_key(void);
ssize_t write_all(int fd, const void *buf, size_t len);

#endif /* HELPER_H */
