//
// Main.c
// KRW
//
// Created by Anonym on 31.08.26.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <LindChain/ProcEnvironment/Surface/kxld/image.h>
#include <LindChain/ProcEnvironment/Utils/klog.h>
#include <LindChain/ProcEnvironment/Surface/surface.h>
#include <LindChain/ProcEnvironment/Surface/sys/core.h>
#include <LindChain/ProcEnvironment/Surface/sys/worker.h>

#define SYS_kslide 	800
#define SYS_kread 	801
#define SYS_kwrite	802
#define SYS_kcall	803

DEFINE_SYSCALL_HANDLER(kslide)
{
	if(!entitlement_got_entitlement(proc_getmaxentitlements(sys_proc_snapshot_), kPEEntitlementFlagLoadKEXT))
	{
		sys_return_failure_with_errno(EPERM);
	}
	
	return _dyld_get_image_vmaddr_slide(0);
}

DEFINE_SYSCALL_HANDLER(kread)
{
	if(!entitlement_got_entitlement(proc_getmaxentitlements(sys_proc_snapshot_), kPEEntitlementFlagLoadKEXT))
	{
		sys_return_failure_with_errno(EPERM);
	}
	
	size_t out_len = (size_t)args[0];
	userspace_pointer_t out = (userspace_pointer_t)args[1];
	kernelspace_pointer_t kout = (kernelspace_pointer_t)args[2];
	if(!syscall_copy_out(sys_task_, out_len, kout, out))
	{
		sys_return_failure_with_errno(EFAULT);
	}
	
	sys_return;
}

DEFINE_SYSCALL_HANDLER(kwrite)
{
	if(!entitlement_got_entitlement(proc_getmaxentitlements(sys_proc_snapshot_), kPEEntitlementFlagLoadKEXT))
	{
		sys_return_failure_with_errno(EPERM);
	}
	
	size_t in_len = (size_t)args[0];
	userspace_pointer_t in = (userspace_pointer_t)args[1];
	kernelspace_pointer_t kin = (kernelspace_pointer_t)args[2];
	if(!syscall_copy_in(sys_task_, in_len, kin, in))
	{
		sys_return_failure_with_errno(EFAULT);
	}
	
	sys_return;
}

typedef uint64_t (*kcall_fn_t)(uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);

DEFINE_SYSCALL_HANDLER(kcall)
{
	if(!entitlement_got_entitlement(proc_getmaxentitlements(sys_proc_snapshot_), kPEEntitlementFlagLoadKEXT))
	{
		sys_return_failure_with_errno(EPERM);
	}
	
	kernelspace_pointer_t kfunc = (kernelspace_pointer_t)args[0];
	size_t argc = (size_t)args[1];
	userspace_pointer_t uargs = (userspace_pointer_t)args[2];
	
	if(argc > 8)
	{
		sys_return_failure_with_errno(EINVAL);
	}
	
	uint64_t kargs[6] = {0};
	if(argc > 0)
	{
		if(!syscall_copy_in(sys_task_, argc * sizeof(uint64_t), (kernelspace_pointer_t)kargs, uargs))
		{
			sys_return_failure_with_errno(EFAULT);
		}
	}
	
	kcall_fn_t fn = (kcall_fn_t)kfunc;
	return (int64_t)fn(kargs[0], kargs[1], kargs[2], kargs[3], kargs[4], kargs[5]);
}

kern_return_t kinit(void)
{
	klog_log("org.emexlabs.KRW", "hello, from kext");
	
	syscall_server_register(ksurface->sys_server, SYS_kslide, GET_SYSCALL_HANDLER(kslide));
	syscall_server_register(ksurface->sys_server, SYS_kread, GET_SYSCALL_HANDLER(kread));
	syscall_server_register(ksurface->sys_server, SYS_kwrite, GET_SYSCALL_HANDLER(kwrite));
	syscall_server_register(ksurface->sys_server, SYS_kcall, GET_SYSCALL_HANDLER(kcall));
	
	klog_log("org.emexlabs.KRW", "registered kernel rw syscalls");
	
	return KERN_SUCCESS;
}

EXPORT_KSURFACE_MODULE({
	.magic = KSURFACE_KMOD_MAGIC,
	.abi_version = KSURFACE_KMOD_ABI_VERSION,
	.identifier = "org.emexlabs.KRW",
	.version = KMOD_VERSION(1, 0, 0),
	.flags = KMOD_FLAG_PERSISTENT,
	.dependency_count = 1,
	.init = kinit,
	.deinit = NULL,
	.start = NULL,
	.stop = NULL,
	.dependencies = {
		{
			.identifier = "ksurface",
			.min_version = KMOD_VERSION(0, 11, 4),
			.max_version = KMOD_VERSION(0, 11, 4),
		}
	},
})
