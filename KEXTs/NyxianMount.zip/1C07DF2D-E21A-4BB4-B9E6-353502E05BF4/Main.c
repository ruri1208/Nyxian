//
// Main.c
// NyxianMount
//
// Created by Anonymous on 30.08.26.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <LindChain/ProcEnvironment/Utils/klog.h>
#include <LindChain/ProcEnvironment/Surface/kxld/image.h>
#include <LindChain/ProcEnvironment/Surface/fs/mount.h>

extern kern_return_t ksurface_relhomemount_mount(FSMountAttr attr, const char *mount_dir, const char *target_dir);

kern_return_t kinit(void)
{
	typedef struct {
		FSMountAttr permissionFlags;
		const char *mount;
		const char *target;
	} FSMountInitRegistry;
	
	/* something like fstab x3 */
	FSMountInitRegistry fstab[] = {
		/* nyxian mount submounts */
		{
			kFSMountAttrRead,
			"/Documents/Projects",
		},
		{
			kFSMountAttrRead,
			"/Documents/SDK",
		},
		{
			kFSMountAttrRead,
			"/Documents/Cache",
		},
		{
			kFSMountAttrRead,
			"/Documents/ModuleCaches",
		},
		{
			kFSMountAttrRead,
			"/Documents/Include",
		},
		{
			kFSMountAttrRead,
			"/Documents/swift",
		},
		{
			kFSMountAttrRead,
			"/Documents/RootCAs",
		},
		{
			kFSMountAttrRead,
			"/Documents/bootstrap.plist",
		},
		
		/* nyxianfs */
		{
			kFSMountAttrRead | kFSMountAttrClear,
			"/Documents/mntfs/nyxianfs",
		},
		
		/* nyxianfs mounts*/
		{
			kFSMountAttrRead,
			"/Documents/mntfs/nyxianfs/Projects",
			"/Documents/Projects",
		},
		{
			kFSMountAttrRead,
			"/Documents/mntfs/nyxianfs/SDK",
			"/Documents/SDK",
		},
		{
			kFSMountAttrRead,
			"/Documents/mntfs/nyxianfs/Cache",
			"/Documents/Cache",
		},
		{
			kFSMountAttrRead,
			"/Documents/mntfs/nyxianfs/ModuleCaches",
			"/Documents/ModuleCaches",
		},
		{
			kFSMountAttrRead,
			"/Documents/mntfs/nyxianfs/Include",
			"/Documents/Include",
		},
		{
			kFSMountAttrRead,
			"/Documents/mntfs/nyxianfs/swift",
			"/Documents/swift",
		},
		{
			kFSMountAttrRead,
			"/Documents/mntfs/nyxianfs/RootCAs",
			"/Documents/RootCAs",
		},
		{
			kFSMountAttrRead,
			"/Documents/mntfs/nyxianfs/bootstrap.plist",
			"/Documents/bootstrap.plist",
		},
		
		/* rootfs nyxianfs mount */
		{
			kFSMountAttrRead,
			"/Documents/mntfs/rootfs/nyxian",
			"/Documents/mntfs/nyxianfs",
		},
	};
	
	for(int i = 0; i < sizeof(fstab) / sizeof(FSMountInitRegistry); i++)
	{
		kern_return_t kr = ksurface_relhomemount_mount(fstab[i].permissionFlags, fstab[i].mount, fstab[i].target);
		if(kr != KERN_SUCCESS)
		{
			klog_log("ksurface:fs", "failed to create %s userspace mount", fstab[i].mount);
			return KERN_FAILURE;
		}
	}
	
	return KERN_SUCCESS;
}

kern_return_t kdeinit(void)
{
	return KERN_NOT_SUPPORTED;
}

EXPORT_KSURFACE_MODULE({
	.magic = KSURFACE_KMOD_MAGIC,
	.abi_version = KSURFACE_KMOD_ABI_VERSION,
	.identifier = "org.emexlabs.NyxianMount",
	.version = KMOD_VERSION(1, 0, 0),
	.flags = KMOD_FLAG_PERSISTENT,
	.dependency_count = 2,
	.init = kinit,
	.deinit = kdeinit,
	.start = NULL,
	.stop = NULL,
	.dependencies = {
		{
			.identifier = "ksurface",
			.min_version = KMOD_VERSION(0, 11, 4),
			.max_version = KMOD_VERSION(0, 11, 4),
		},
		{
			.identifier = "org.emexlabs.RelHomeMount",
			.min_version = KMOD_VERSION(1, 0, 0),
			.max_version = KMOD_VERSION(1, 0, 0),
		}
	},
})
