//
// Main.c
// TestTweak
//
// Created by Anonym on 11.09.26.
//

@import Foundation;
@import UIKit;
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <LindChain/ProcEnvironment/Surface/kxld/image.h>
#include <LindChain/ProcEnvironment/Utils/klog.h>
#import <UI/UIInit/NXUITableViewController.h>

extern void PreferenceLoaderAppendEntry(NSString *name, UIImage *previewImage, Class vcClass);

@interface TestTweakSettings: NXUITableViewController
@end

@implementation TestTweakSettings

- (void)viewDidLoad
{
	[super viewDidLoad];
	
	self.title = @"MEOWWW";
}

@end

kern_return_t kinit(void)
{
	klog_log("org.emexlabs.TestTweak", "hello, from kext");
	PreferenceLoaderAppendEntry(@"TestTweak", nil, [TestTweakSettings class]);
	return KERN_SUCCESS;
}

EXPORT_KSURFACE_MODULE({
	.magic = KSURFACE_KMOD_MAGIC,
	.abi_version = KSURFACE_KMOD_ABI_VERSION,
	.identifier = "org.emexlabs.TestTweak",
	.version = KMOD_VERSION(1, 0, 0),
	.flags = KMOD_FLAG_NONE,
	.dependency_count = 2,
	.init = kinit,
	.deinit = NULL,
	.start = NULL,
	.stop = NULL,
	.dependencies = {
		{
			.identifier = "ksurface",
			.min_version = KMOD_VERSION(0, 11, 5),
			.max_version = KMOD_VERSION(0, 11, 5),
		},
		{
			.identifier = "org.emexlabs.BasePreferenceLoader",
			.min_version = KMOD_VERSION(1, 0, 0),
			.max_version = KMOD_VERSION(1, 0, 0),
		}
	},
})
