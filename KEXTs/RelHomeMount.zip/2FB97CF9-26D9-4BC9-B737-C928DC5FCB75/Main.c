//
// Main.c
// RelHomeMount
//
// Created by Anonymous on 30.08.26.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <LindChain/ProcEnvironment/Utils/klog.h>
#include <LindChain/ProcEnvironment/Surface/kxld/image.h>
#include <LindChain/ProcEnvironment/Surface/fs/mount.h>

static kern_return_t path_join_home(char *out, size_t out_size, const char *home, const char *rel)
{
	size_t home_len = strlen(home);
	
	while(home_len > 0 && home[home_len - 1] == '/')
	{
		home_len--;
	}
	
	while(*rel == '/')
	{
		rel++;
	}
	
	int n;
	if(*rel == '\0')
	{
		n = snprintf(out, out_size, "%.*s", (int)home_len, home);
	}
	else
	{
		n = snprintf(out, out_size, "%.*s/%s", (int)home_len, home, rel);
	}
	
	if(n < 0 || (size_t)n >= out_size)
	{
		return KERN_FAILURE;
	}
	
	return KERN_SUCCESS;
}

extern kern_return_t ksurface_relhomemount_mount(FSMountAttr attr, const char *mount_dir, const char *target_dir)
{
	const char *home = getenv("HOME");
	if(home == NULL || mount_dir == NULL)
	{
		return KERN_FAILURE;
	}
	
	char mount_rel[PATH_MAX];
	char target_rel[PATH_MAX];

	if(path_join_home(mount_rel, sizeof(mount_rel), home, mount_dir) != KERN_SUCCESS)
	{
		return KERN_FAILURE;
	}
	
	if(target_dir != NULL)
	{
		if(path_join_home(target_rel, sizeof(target_rel), home, target_dir) != KERN_SUCCESS)
		{
			return KERN_FAILURE;
		}
		return ksurface_fs_mount(attr, mount_rel, target_rel);
	}
	
	return ksurface_fs_mount(attr, mount_rel, NULL);
}

EXPORT_KSURFACE_MODULE({
	.magic = KSURFACE_KMOD_MAGIC,
	.abi_version = KSURFACE_KMOD_ABI_VERSION,
	.identifier = "org.emexlabs.RelHomeMount",
	.version = KMOD_VERSION(1, 0, 0),
	.flags = KMOD_FLAG_PERSISTENT | KMOD_FLAG_OVERRIDE_CORE,
	.dependency_count = 1,
	.init = 	NULL,
	.deinit = NULL,
	.start = NULL,
	.stop = NULL,
	.dependencies = {
		{
			.identifier = "ksurface",
			.min_version = KMOD_VERSION(0, 11, 4),
			.max_version = KMOD_VERSION(0, 11, 4),
		}
	},
})
