//
// Main.c
// bruh
//
// Created by Anonym on 28.08.26.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <LindChain/ProcEnvironment/Utils/klog.h>
#include <LindChain/ProcEnvironment/Surface/surface.h>
#include <LindChain/ProcEnvironment/Surface/kxld/image.h>

EXPORT_KSURFACE_MODULE({
	.magic = KSURFACE_KMOD_MAGIC,
	.abi_version = KSURFACE_KMOD_ABI_VERSION,
	.identifier = "org.emexlabs.ColorWinMix",
	.version = KMOD_VERSION(1, 0, 0),
	.flags = KMOD_FLAG_PERSISTENT,
	.dependency_count = 1,
	.init = NULL,
	.deinit = NULL,
	.start = NULL,
	.stop = NULL,
	.dependencies = {
		{
			.identifier = "ksurface",
			.min_version = KMOD_VERSION(0, 11, 4),
			.max_version = KMOD_VERSION(0, 11, 4),
		}
	},
})

