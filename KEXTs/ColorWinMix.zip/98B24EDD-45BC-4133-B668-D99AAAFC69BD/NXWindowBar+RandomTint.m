//
// Reboot.m
// bruh
//
// Created by Anonym on 28.08.26.
//

#import <LindChain/WindowServer/Window/NXWindowBar.h>
#import <LindChain/WindowServer/Session/NXWindowSessionApplication.h>
#import <LindChain/Utils/Swizzle.h>
#include <LindChain/ProcEnvironment/Utils/klog.h>
#import <objc/runtime.h>
#import <UIKit/UIKit.h>

UIColor *UIAverageColorOfImage(UIImage *image)
{
	CGImageRef cgImage = image.CGImage;
	if(!cgImage)
	{
		return nil;
	}
	
	uint8_t rgba[4] = {0, 0, 0, 0};
	CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
	CGContextRef ctx = CGBitmapContextCreate(rgba, 1, 1, 8, 4, space, kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big);
	CGColorSpaceRelease(space);
	if(!ctx)
	{
		return nil;
	}
	
	CGContextSetInterpolationQuality(ctx, kCGInterpolationHigh);
	CGContextDrawImage(ctx, CGRectMake(0, 0, 1, 1), cgImage);
	CGContextRelease(ctx);
	
	CGFloat a = rgba[3] / 255.0;
	if(a <= 0.0)
	{
		return UIColor.clearColor;
	}
	
	CGFloat r = MIN((rgba[0] / 255.0) / a, 1.0);
	CGFloat g = MIN((rgba[1] / 255.0) / a, 1.0);
	CGFloat b = MIN((rgba[2] / 255.0) / a, 1.0);
	
	return [UIColor colorWithRed:r green:g blue:b alpha:a];
}

static inline CGFloat UIClamp(CGFloat v, CGFloat lo, CGFloat hi)
{
	return v < lo ? lo : (v > hi ? hi : v);
}

UIColor *UIBarColorFromImage(UIImage *image)
{
	UIColor *avg = UIAverageColorOfImage(image);
	if(!avg)
	{
		return nil;
	}
	
	CGFloat h = 0, s = 0, b = 0, a = 1;
	if(![avg getHue:&h saturation:&s brightness:&b alpha:&a])
	{
		[avg getWhite:&b alpha:&a];
		h = 0; s = 0;
	}
	
	BOOL chromatic = (s >= 0.05);
	s = chromatic ? UIClamp(s, 0.12, 0.55) : 0.0;
	
	CGFloat darkB  = UIClamp(b * 0.30, 0.10, 0.24);
	CGFloat lightB = UIClamp(0.98 - (1.0 - b) * 0.18, 0.88, 0.98);
	
	CGFloat darkS  = chromatic ? UIClamp(s * 1.25, 0.0, 0.62) : 0.0;
	CGFloat lightS = chromatic ? UIClamp(s * 0.50, 0.0, 0.30) : 0.0;
	
	UIColor *dark  = [UIColor colorWithHue:h saturation:darkS brightness:darkB alpha:1.0];
	UIColor *light = [UIColor colorWithHue:h saturation:lightS brightness:lightB alpha:1.0];
	
	return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *tc) {
		return tc.userInterfaceStyle == UIUserInterfaceStyleDark ? dark : light;
	}];
}

@interface NXWindowSessionApplication (RandomTint)
@end

@implementation NXWindowSessionApplication (RandomTint)

- (void)didMoveToParentViewController:(UIViewController*)parent
{
	if(self.process.applicationObject.icon)
	{
		klog_log("ColorWinMix", "application object: %@", self.process.applicationObject.icon);
		
		UIStackView *contentStack = nil;
		for(UIView *sub in self.window.view.subviews)
		{
			if(![sub isKindOfClass:UIStackView.class])
			{
				continue;
			}
			contentStack = (UIStackView*)sub;
		}
		if(!contentStack)
		{
			return;
		}
		
		klog_log("ColorWinMix", "contentStack: %@", contentStack);
		
		NXWindowBar *windowBar = nil;
		for(UIView *sub in contentStack.subviews)
		{
			if(![sub isKindOfClass:NXWindowBar.class])
			{
				continue;
			}
			windowBar = (NXWindowBar*)sub;
		}
		if(!windowBar)
		{
			return;
		}
		
		klog_log("ColorWinMix", "windowBar: %@", windowBar);
		
		UIColor *averageTint = UIBarColorFromImage(self.process.applicationObject.icon);
		
		UIVisualEffectView *background = nil;
		for(UIView *sub in windowBar.subviews)
		{
			if(![sub isKindOfClass:UIVisualEffectView.class])
			{
				continue;
			}
			if(sub == windowBar.buttonIsland)
			{
				continue;
			}
			background = (UIVisualEffectView *)sub;
		}
		if(!background)
		{
			return;
		}
		
		UIView *tint = [[UIView alloc] init];
		tint.translatesAutoresizingMaskIntoConstraints = NO;
		tint.backgroundColor = averageTint;
		tint.userInteractionEnabled = NO;
		[background.contentView addSubview:tint];
		
		[NSLayoutConstraint activateConstraints:@[
			[tint.topAnchor constraintEqualToAnchor:background.contentView.topAnchor],
			[tint.bottomAnchor constraintEqualToAnchor:background.contentView.bottomAnchor],
			[tint.leadingAnchor constraintEqualToAnchor:background.contentView.leadingAnchor],
			[tint.trailingAnchor constraintEqualToAnchor:background.contentView.trailingAnchor],
		]];
	}
	[super didMoveToParentViewController:parent];
}

@end
