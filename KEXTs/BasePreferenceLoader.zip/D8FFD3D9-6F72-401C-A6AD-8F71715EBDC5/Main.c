//
// Main.c
// PreferencesLoader
//
// Created by Anonym on 10.09.26.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <LindChain/ProcEnvironment/Surface/kxld/image.h>
#include <LindChain/ProcEnvironment/Utils/klog.h>

kern_return_t kinit(void);

EXPORT_KSURFACE_MODULE({
	.magic = KSURFACE_KMOD_MAGIC,
	.abi_version = KSURFACE_KMOD_ABI_VERSION,
	.identifier = "org.emexlabs.BasePreferenceLoader",
	.version = KMOD_VERSION(1, 0, 0),
	.flags = KMOD_FLAG_PERSISTENT,
	.dependency_count = 2,
	.init = kinit,
	.deinit = NULL,
	.start = NULL,
	.stop = NULL,
	.dependencies = {
		{
			.identifier = "ksurface",
			.min_version = KMOD_VERSION(0, 11, 5),
			.max_version = KMOD_VERSION(0, 11, 5),
		},
		{
			.identifier = "org.emexlabs.RelHomeMount",
			.min_version = KMOD_VERSION(1, 0, 1),
			.max_version = KMOD_VERSION(1, 0, 1),
		}
	},
})
