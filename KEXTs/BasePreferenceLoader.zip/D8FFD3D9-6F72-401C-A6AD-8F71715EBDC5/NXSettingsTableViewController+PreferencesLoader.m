//
// SettingsViewController+PreferencesLoader.m
// PreferencesLoader
//
// Created by Anonym on 10.09.26.
//

@import Foundation;
@import UIKit;
#import <UI/Settings/NXSettingsTableViewController.h>
#import <LindChain/Utils/Swizzle.h>
#import <LindChain/ProcEnvironment/Utils/klog.h>
#import <LindChain/ProcEnvironment/Surface/fs/mount.h>
#import <LindChain/ProcEnvironment/PELaunchServiceManager.h>
#import <os/lock.h>

@interface PreferenceLoaderEntry: NSObject

@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) UIImage *previewImage;
@property (nonatomic,strong) Class vcClass;

@end

@implementation PreferenceLoaderEntry
@end

static NSMutableArray<PreferenceLoaderEntry*> *entries;
static os_unfair_lock lock = OS_UNFAIR_LOCK_INIT;

extern void PreferenceLoaderAppendEntry(NSString *name, UIImage *previewImage, Class vcClass)
{
	os_unfair_lock_lock(&lock);
	PreferenceLoaderEntry *entry = PreferenceLoaderEntry.new;
	if(entry == nil)
	{
		os_unfair_lock_unlock(&lock);
		return;
	}
	
	entry.name = name;
	entry.previewImage = previewImage;
	entry.vcClass = vcClass;
	[entries addObject:entry];
	
	os_unfair_lock_unlock(&lock);
}

@interface NXSettingsTableViewController (PreferencesLoader)
@end

@implementation NXSettingsTableViewController (PreferencesLoader)

- (CFIndex)numberOfSectionsInTableView:(UITableView *)tableView
{
	os_unfair_lock_lock(&lock);
	CFIndex count = [entries count];
	os_unfair_lock_unlock(&lock);
	return count > 0 ? 2 : 1;
}

- (CFIndex)hook_tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if(section == 0)
	{
		return [self hook_tableView:tableView numberOfRowsInSection:section];
	}
	os_unfair_lock_lock(&lock);
	CFIndex count = [entries count];
	os_unfair_lock_unlock(&lock);
	return count;
}

- (UITableViewCell*)hook_tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(indexPath.section == 0)
	{
		return [self hook_tableView:tableView cellForRowAtIndexPath:indexPath];
	}
	
	os_unfair_lock_lock(&lock);
	PreferenceLoaderEntry *entry = [entries objectAtIndex:indexPath.row];
	os_unfair_lock_unlock(&lock);
	
	UITableViewCell *cell = [[UITableViewCell alloc] init];
	if(entry == NULL)
	{
		return cell;
	}
	
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	cell.imageView.image = entry.previewImage;
	cell.textLabel.text = entry.name;
	return cell;
}

- (NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
	if(section == 0)
	{
		return @"General";
	}
	return @"Tweaks";
}

- (void)hook_tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(indexPath.section == 0)
	{
		[self hook_tableView:tableView didSelectRowAtIndexPath:indexPath];
	}
	else
	{
		[tableView deselectRowAtIndexPath:indexPath animated:YES];
		
		os_unfair_lock_lock(&lock);
		PreferenceLoaderEntry *entry = [entries objectAtIndex:indexPath.row];
		os_unfair_lock_unlock(&lock);
		
		if(entry == nil)
		{
			return;
		}
		
		[self.navigationController pushViewController:[[entry.vcClass alloc] init] animated:YES];
	}
}

@end

kern_return_t kinit(void)
{
	entries = [NSMutableArray array];
	klog_log("org.emexlabs.PreferenceLoader", "swizzling NXSettingsTableViewController");
	SwizzleObjCMethod(@selector(tableView:cellForRowAtIndexPath:), [NXSettingsTableViewController class], @selector(hook_tableView:cellForRowAtIndexPath:), nil, kSwizzleMethodTypeInstance);
	SwizzleObjCMethod(@selector(tableView:numberOfRowsInSection:), [NXSettingsTableViewController class], @selector(hook_tableView:numberOfRowsInSection:), nil, kSwizzleMethodTypeInstance);
	SwizzleObjCMethod(@selector(tableView:didSelectRowAtIndexPath:), [NXSettingsTableViewController class], @selector(hook_tableView:didSelectRowAtIndexPath:), nil, kSwizzleMethodTypeInstance);
	
	klog_log("org.emexlabs.PreferenceLoader", "creating preferences mount");
	extern kern_return_t ksurface_relhomemount_mount(FSMountAttr attr, const char *mount_dir, const char *target_dir);
	
	return ksurface_relhomemount_mount(kFSMountAttrRead | kFSMountAttrWrite, "/Documents/rootfs/Library/Preferences", NULL);
}
