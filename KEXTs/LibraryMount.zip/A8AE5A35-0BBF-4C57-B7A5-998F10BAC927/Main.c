//
// Main.c
// NyxianMount
//
// Created by Anonymous on 30.08.26.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <LindChain/ProcEnvironment/Utils/klog.h>
#include <LindChain/ProcEnvironment/Surface/kxld/image.h>
#include <LindChain/ProcEnvironment/Surface/fs/mount.h>

extern kern_return_t ksurface_relhomemount_mount(FSMountAttr attr, const char *mount_dir, const char *target_dir);

kern_return_t kinit(void)
{
	typedef struct {
		FSMountAttr permissionFlags;
		const char *mount;
		const char *target;
	} FSMountInitRegistry;
	
	/* something like fstab x3 */
	FSMountInitRegistry fstab[] = {
		/* home mount submounts */
		{
			kFSMountAttrRead,
			"/Library",
		},
		
		/* library mount */
		{
			kFSMountAttrRead,
			"/Documents/mntfs/nyxianfs/Library",
			"/Library",
		},
	};
	
	for(int i = 0; i < sizeof(fstab) / sizeof(FSMountInitRegistry); i++)
	{
		kern_return_t kr = ksurface_relhomemount_mount(fstab[i].permissionFlags, fstab[i].mount, fstab[i].target);
		if(kr != KERN_SUCCESS)
		{
			klog_log("ksurface:fs", "failed to create %s userspace mount", fstab[i].mount);
			return KERN_FAILURE;
		}
	}
	
	return KERN_SUCCESS;
}

kern_return_t kdeinit(void)
{
	return KERN_NOT_SUPPORTED;
}

EXPORT_KSURFACE_MODULE({
	.magic = KSURFACE_KMOD_MAGIC,
	.abi_version = KSURFACE_KMOD_ABI_VERSION,
	.identifier = "org.emexlabs.LibraryMount",
	.version = KMOD_VERSION(1, 0, 0),
	.flags = KMOD_FLAG_PERSISTENT,
	.dependency_count = 3,
	.init = kinit,
	.deinit = kdeinit,
	.start = NULL,
	.stop = NULL,
	.dependencies = {
		{
			.identifier = "ksurface",
			.min_version = KMOD_VERSION(0, 11, 4),
			.max_version = KMOD_VERSION(0, 11, 4),
		},
		{
			.identifier = "org.emexlabs.RelHomeMount",
			.min_version = KMOD_VERSION(1, 0, 0),
			.max_version = KMOD_VERSION(1, 0, 0),
		},
		{
			.identifier = "org.emexlabs.NyxianMount",
			.min_version = KMOD_VERSION(1, 0, 0),
			.max_version = KMOD_VERSION(1, 0, 0),
		},
	},
})
